#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

	// Função auxiliar para trocar elementos 
	void swap(int arr[], int i, int j) {
    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}
	//bubblesort
	void bubblesort(int arr[], int n){
		int i, j, temp;
		for(i=0;i<n-1;i++){
			for(j=0;j<n-i-1;j++){
				if(arr[j]>arr[j+1]){
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
			}
		}
	}
}

	//selectinsort
	void selectionsort(int arr[], int n){
		int i, j, min_idx, temp;
		for(i=0; i<n-1; i++){
			for(j=i+1; j<n; j++){
				if(arr[j]<arr[min_idx]){
					min_idx=j;
				}
				
			}
			temp = arr[min_idx];
			arr[min_idx] = arr[i];
			arr[i] = temp;
		}
	}
	
	//InsertionSort
	void insertionSort(int arr[], int n) {
		int i, key, j;
		for (i=1; i<n; i++) {
			key = arr[i];
			j = i-1;
				while (j>=0 && arr[j]>key) {
					arr[j+1] = arr[j];
					j = j-1;
		}
		arr[j+1] = key;
	}
}
	//partição
	int partition(int arr[], int low, int high) {
		int pivot = arr[high];
		int i = (low-1);
		for (int j=low; j<=high-1; j++) {
			if (arr[j]<pivot) {
				i++;
				swap(arr, i, j);
		}
	}
	swap(arr, i + 1, high);
	return (i + 1);
		}
	//QuickSort
	void quicksort(int arr[], int low, int high) {
		int pi;
		if (low<high) {
			pi = partition(arr, low, high);
			quicksort(arr, low, pi-1);
			quicksort(arr, pi+1, high);
	}
}

	
	//Mergesort
	void merge(int arr[], int l, int m, int r) {
    int i, j, k;
    int n1 = m-l+1; 
    int n2 = r-m;     

    int L[n1], R[n2];
    for (i=0; i<n1; i++) {
		L[i] = arr[l+i];	
		}
    for (j=0; j<n2; j++) {
		R[j] = arr[m+1+j];	
		}
    i=0; j=0; k=l; 
    	while (i<n1 && j<n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1) {
        arr[k] = L[i];
        i++; k++;
    }
    while (j<n2) {
        arr[k] = R[j];
        j++; k++;
    }
}
void mergesort(int arr[], int l, int r) {
    if (l<r) {
        int m = l+(r-l)/2;
        mergesort(arr, l, m);
        mergesort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}




//Função para imprimir o array
void printArray(int arr[], int n) {
    int i;
    for (i=0; i<n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}
int main(int argc, char *argv[]) {
	int original[] = {64, 34, 25, 12, 22, 11, 90, 5, 1, 45};
    int n = 10;
    int arr[10];
    int i;
    clock_t start, end;
    double tempo;

    //TESTE BUBBLE SORT
    for(i = 0; i < n; i++) arr[i] = original[i];
    printf("1. BUBBLE SORT\n");
    printf("Antes:  "); printArray(arr, n);
    start = clock();
    bubblesort(arr, n);
    end = clock();
    printf("Depois: "); printArray(arr, n);
    printf("Tempo:  %f segundos\n\n", (double)(end - start) / CLOCKS_PER_SEC);

    //TESTE SELECTION SORT
    for(i = 0; i < n; i++) arr[i] = original[i];
    printf("2. SELECTION SORT\n");
    printf("Antes:  "); printArray(arr, n);
    start = clock();
    selectionsort(arr, n);
    end = clock();
    printf("Depois: "); printArray(arr, n);
    printf("Tempo:  %f segundos\n\n", (double)(end - start) / CLOCKS_PER_SEC);

    // TESTE INSERTION SORT
    for(i = 0; i < n; i++) arr[i] = original[i]; 
    printf("3. INSERTION SORT\n");
    printf("Antes:  "); printArray(arr, n);
    start = clock();
    insertionSort(arr, n);
    end = clock();
    printf("Depois: "); printArray(arr, n);
    printf("Tempo:  %f segundos\n\n", (double)(end - start) / CLOCKS_PER_SEC);

    // TESTE QUICK SORT
    for(i = 0; i < n; i++) arr[i] = original[i]; 
    printf("4. QUICK SORT\n");
    printf("Antes:  "); printArray(arr, n);
    start = clock();
    quicksort(arr, 0, n - 1);
    end = clock();
    printf("Depois: "); printArray(arr, n);
    printf("Tempo:  %f segundos\n\n", (double)(end - start) / CLOCKS_PER_SEC);

    //TESTE MERGE SORT
    for(i = 0; i < n; i++) arr[i] = original[i];
    printf("5. MERGE SORT\n");
    printf("Antes:  "); printArray(arr, n);
    start = clock();
    mergesort(arr, 0, n - 1);
    end = clock();
    printf("Depois: "); printArray(arr, n);
    printf("Tempo:  %f segundos\n\n", (double)(end - start) / CLOCKS_PER_SEC);

    printf("================================================\n");
    return 0;
}